/* 
 * Copyright (C) 2006 David Boyce.  All rights reserved.
 * Based on code purchased via RentACoder.com (Request Id 401892).
 *
 * This program is free software; you may redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
	Description:
		Patch an OBJ file
**/

#include "obj.h"
#include "patch.h"
#include "com.h"

/**
* Patch the export table
* RET: TRUE if sucess, else FALSE
*/
BOOL
patch_obj(PIMAGE_FILE_HEADER p_pFileHdr)
{
    PIMAGE_SECTION_HEADER pSection;
    INT i;

    LOGSTRPTR("OBJ TimeDateStamp: ",
	    (ULONG_PTR) p_pFileHdr->TimeDateStamp);
    p_pFileHdr->TimeDateStamp = 0;

    /* Get first section */
    pSection = MAKE_PTR(PIMAGE_SECTION_HEADER,
	    p_pFileHdr->SizeOfOptionalHeader, (p_pFileHdr + 1));

    for (i = 0; i < p_pFileHdr->NumberOfSections; i++) {
	LOGSTR(pSection[i].Name);
	LOGPTR(pSection[i].Characteristics);
	LOGPTR(pSection[i].PointerToRawData);
	LOGPTR(pSection[i].SizeOfRawData);

	/* check if its CV4 type or symbol information */
	if (strcmpi(pSection[i].Name, ".debug$T") == 0 ||
		strcmpi(pSection[i].Name, ".debug$S") == 0) {
	    PBYTE pByte =
		    MAKE_PTR(LPVOID, pSection[i].PointerToRawData,
		    g_baseAddr);
	    /* zero out the whole section because no docs on how its structured can
	       be found at this moment. Its only debug info and it wont end up in the
	       final EXE anyway, so no muhc harm done. And if one would change the code,
	       then the debug info would change too so we are not loosing any valuable
	       information, just variable names / functionnames etc. */
	    /* Patch it! */
	    memset(pByte, 0x00, pSection[i].SizeOfRawData);

	    /* Check if its a metadata header .NET OBJs */
	} else if (strcmpi(pSection[i].Name, ".cormeta") == 0) {
	    PMETADATA_HEADER pMetaDataHdr = MAKE_PTR(PMETADATA_HEADER,
		    pSection[i].PointerToRawData,
		    g_baseAddr);
	    patch_metadata(pMetaDataHdr);
	}
    }

    return TRUE;
}
