/* 
 * Copyright (C) 2006 David Boyce.  All rights reserved.
 * Based on code purchased via RentACoder.com (Request Id 401892).
 *
 * This program is free software; you may redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
	Description:
		Patch the basic parts of a PE
**/

#include "patch.h"
#include "export.h"
#include "import.h"
#include "resource.h"
#include "bound.h"
#include "debug.h"
#include "loadconfig.h"
#include "com.h"
#include "obj.h"

/* Some commonly used globals */
ULONG_PTR g_baseAddr = 0;
PIMAGE_DOS_HEADER g_pDosHeader = NULL;
PIMAGE_NT_HEADERS g_pNTHeader = NULL;
PIMAGE_SECTION_HEADER g_pFirstSection = NULL;
BOOL g_is64bit = FALSE;

/* All the possible file characteristics */
FLAGTOSTR imgFileFlags[] = {
    {0x0001, "IMAGE_FILE_RELOCS_STRIPPED"}
    ,
    {0x0002, "IMAGE_FILE_EXECUTABLE_IMAGE"}
    ,
    {0x0004, "IMAGE_FILE_LINE_NUMS_STRIPPED"}
    ,
    {0x0008, "IMAGE_FILE_LOCAL_SYMS_STRIPPED"}
    ,
    {0x0010, "IMAGE_FILE_AGGRESIVE_WS_TRIM"}
    ,
    {0x0020, "IMAGE_FILE_LARGE_ADDRESS_AWARE"}
    ,
    {0x0080, "IMAGE_FILE_BYTES_REVERSED_LO"}
    ,
    {0x0100, "IMAGE_FILE_32BIT_MACHINE"}
    ,
    {0x0200, "IMAGE_FILE_DEBUG_STRIPPED"}
    ,
    {0x0400, "IMAGE_FILE_REMOVABLE_RUN_FROM_SWAP"}
    ,
    {0x0800, "IMAGE_FILE_NET_RUN_FROM_SWAP"}
    ,
    {0x1000, "IMAGE_FILE_SYSTEM"}
    ,
    {0x2000, "IMAGE_FILE_DLL"}
    ,
    {0x4000, "IMAGE_FILE_UP_SYSTEM_ONLY"}
    ,
    {0x8000, "IMAGE_FILE_BYTES_REVERSED_HI"}
    ,
};

#define NUM_FILE_CHARACTERISTICS		15

/* All the possible data directories */
FLAGTOSTR dataDirs[] = {
    {0, "IMAGE_DIRECTORY_ENTRY_EXPORT"}
    ,
    {1, "IMAGE_DIRECTORY_ENTRY_IMPORT"}
    ,
    {2, "IMAGE_DIRECTORY_ENTRY_RESOURCE"}
    ,
    {3, "IMAGE_DIRECTORY_ENTRY_EXCEPTION"}
    ,
    {4, "IMAGE_DIRECTORY_ENTRY_SECURITY"}
    ,
    {5, "IMAGE_DIRECTORY_ENTRY_BASERELOC"}
    ,
    {6, "IMAGE_DIRECTORY_ENTRY_DEBUG"}
    ,
    {7, "IMAGE_DIRECTORY_ENTRY_ARCHITECTURE"}
    ,
    {8, "IMAGE_DIRECTORY_ENTRY_GLOBALPTR"}
    ,
    {9, "IMAGE_DIRECTORY_ENTRY_TLS"}
    ,
    {10, "IMAGE_DIRECTORY_ENTRY_LOAD_CONFIG"}
    ,
    {11, "IMAGE_DIRECTORY_ENTRY_BOUND_IMPORT"}
    ,
    {12, "IMAGE_DIRECTORY_ENTRY_IAT"}
    ,
    {13, "IMAGE_DIRECTORY_ENTRY_DELAY_IMPORT"}
    ,
    {14, "IMAGE_DIRECTORY_ENTRY_COM_DESCRIPTOR"}
    ,
    {15, "UNUSED"}
    ,
};

/**
* Print some info about this file
*/
VOID
print_file_characteristics(DWORD p_flags)
{
    INT i;
    for (i = 0; i < NUM_FILE_CHARACTERISTICS; i++) {
	if (imgFileFlags[i].m_flag & p_flags)
	    LOG(imgFileFlags[i].m_str);
    }
}

/**
* Dump some info about the availible sections
*/
VOID
dump_sections()
{
    PIMAGE_SECTION_HEADER pSectionHead = NULL;
    DWORD i;

    LOG("---SECTIONS-------------------------------------------------------");
    pSectionHead = g_pFirstSection;
    for (i = 0; i < g_pNTHeader->FileHeader.NumberOfSections;
	    i++, pSectionHead++) {
	DWORD start = pSectionHead->PointerToRawData;
	DWORD end =
		pSectionHead->PointerToRawData +
		pSectionHead->SizeOfRawData;
	LOGSTR(pSectionHead->Name);
	LOGTAB();
	LOGPTR(start);
	LOGTAB();
	LOGPTR(end);
    }
    LOG("---END SECTIONS---------------------------------------------------");
}

/**
* Find the section containing a certain RVA
* IN: 'p_RVA' relative virtual address
* RET: pointer to section, or NULL
*/
PIMAGE_SECTION_HEADER
find_section(DWORD p_RVA)
{
    DWORD i;
    PIMAGE_SECTION_HEADER pSectionHead = NULL;

    assert(g_pFirstSection);
    assert(g_pNTHeader);

    pSectionHead = g_pFirstSection;
    for (i = 0; i < g_pNTHeader->FileHeader.NumberOfSections;
	    i++, pSectionHead++) {
	DWORD startRVA = pSectionHead->VirtualAddress;
	DWORD endRVA =
		pSectionHead->VirtualAddress +
		pSectionHead->Misc.VirtualSize;
	if (p_RVA >= startRVA && p_RVA < endRVA)
	    return pSectionHead;
    }
    return NULL;
}

/**
* Convert an RVA to a usuable pointer
* IN: 'p_RVA' relative virtual address
* RET: a pointer, or NULL
*/
LPVOID
rva_to_ptr(DWORD p_RVA)
{
    PIMAGE_SECTION_HEADER pSection;
    pSection = find_section(p_RVA);
    if (pSection == NULL)
	return NULL;
    return MAKE_PTR(LPVOID, g_baseAddr,
	    (p_RVA - (pSection->VirtualAddress -
			    pSection->PointerToRawData)));
}

/**
* Get a pointer to a data directory of the PE
* IN: 'p_DataDir' the ID of the dir we want
* RET: pointer to data directory
*/
PIMAGE_DATA_DIRECTORY
get_data_dir(DWORD p_DataDir)
{
    PIMAGE_DATA_DIRECTORY pDataDir = NULL;

    assert(p_DataDir < IMAGE_NUMBEROF_DIRECTORY_ENTRIES);
    assert(g_baseAddr && g_pDosHeader);

    if (g_is64bit) {
	PIMAGE_NT_HEADERS64 pNTHead =
		MAKE_PTR(PIMAGE_NT_HEADERS64, g_baseAddr,
		g_pDosHeader->e_lfanew);
	pDataDir = &pNTHead->OptionalHeader.DataDirectory[p_DataDir];
    } else {
	PIMAGE_NT_HEADERS32 pNTHead =
		MAKE_PTR(PIMAGE_NT_HEADERS32, g_baseAddr,
		g_pDosHeader->e_lfanew);
	pDataDir = &pNTHead->OptionalHeader.DataDirectory[p_DataDir];
    }
    return pDataDir;
}

/**
* log some info about available data directories
* DEBUG_OUTPUT must be defined.
*/
VOID
print_data_directories()
{
    INT i;
    for (i = 0; i < IMAGE_NUMBEROF_DIRECTORY_ENTRIES; i++) {
	PIMAGE_DATA_DIRECTORY pDataDir = get_data_dir(i);
	if (pDataDir != NULL && pDataDir->Size != 0) {
	    LOG(dataDirs[i].m_str);
	    LOGPTR(pDataDir->VirtualAddress);
	    LOGPTR(pDataDir->Size);
	}
    }
}

/**
* Patch the optional header. At the same time find out if this is a
* 32 or 64 bit file.
* IN: 'p_pNTHeader' pointer to the nt header structure
* RET: TRUE if this is a 64 bit file, else FALSE
*/
BOOL
patch_optional_header(PIMAGE_NT_HEADERS p_pNTHeader)
{
    BOOL is64Bit = FALSE;
    /* Check if its 64 or 32 bit */
    is64Bit = (p_pNTHeader->FileHeader.Machine == IMAGE_FILE_MACHINE_IA64)
	    || (p_pNTHeader->FileHeader.Machine ==
	    IMAGE_FILE_MACHINE_ALPHA64)
	    || (p_pNTHeader->FileHeader.Machine ==
	    IMAGE_FILE_MACHINE_AMD64);
    /* Patch it! */
    p_pNTHeader->FileHeader.TimeDateStamp = 0;
    if (is64Bit == TRUE) {
	PIMAGE_NT_HEADERS64 pNT64 = (PIMAGE_NT_HEADERS64) p_pNTHeader;
	/* Patch it! */
	pNT64->OptionalHeader.CheckSum = 0;
    } else {
	PIMAGE_NT_HEADERS32 pNT32 = (PIMAGE_NT_HEADERS32) p_pNTHeader;
	/* Patch it! */
	pNT32->OptionalHeader.CheckSum = 0;
    }
    return is64Bit;
}

/**
* Patch a memory mapped file
* IN: 'p_baseAddress' base address of mapping
*/
VOID
patch_mapped_file(LPVOID p_baseAddress)
{
    g_baseAddr = (ULONG_PTR) p_baseAddress;
    g_pDosHeader = (PIMAGE_DOS_HEADER) g_baseAddr;

    if (g_pDosHeader->e_magic == IMAGE_DOS_SIGNATURE) {
	g_pNTHeader = MAKE_PTR(PIMAGE_NT_HEADERS, g_baseAddr,
		g_pDosHeader->e_lfanew);

	g_is64bit = patch_optional_header(g_pNTHeader);
	LOGPTR(g_is64bit);
	print_file_characteristics(g_pNTHeader->FileHeader.
		Characteristics);
	if (g_pNTHeader->Signature == IMAGE_NT_SIGNATURE) {
	    /* save a pointer to the first section in PE for later use */
	    g_pFirstSection = MAKE_PTR(PIMAGE_SECTION_HEADER, g_pNTHeader,
		    (g_is64bit ? sizeof(IMAGE_NT_HEADERS64) :
			    sizeof(IMAGE_NT_HEADERS32))
		    );

	    print_data_directories();
	    dump_sections();

	    __try {
		/* Patch sections known to contain timestamps */
		patch_export();
		patch_import();	/* DateTimeStamp unused? */
		patch_resource();	/* DateTimeStamp unused? */
		patch_bound();
		patch_debug();
		patch_loadconfig();
		patch_com_descriptor();	/* For .NET EXEs */
	    }
	    __except(1) {
		/*  */
		LOG("Exception while patching EXE / DLL");
	    }
	} else {
	    /* Not an NT signature */
	    LOG("Not an NT signature");
	}
    } else {
	/* Not a DOS signature */
	PIMAGE_FILE_HEADER pFileHdr = (PIMAGE_FILE_HEADER) g_baseAddr;
	/* Check if its an OBJ file */
	if (pFileHdr->Machine == IMAGE_FILE_MACHINE_I386 ||
		pFileHdr->Machine == IMAGE_FILE_MACHINE_ALPHA ||
		pFileHdr->Machine == IMAGE_FILE_MACHINE_IA64 ||
		pFileHdr->Machine == IMAGE_FILE_MACHINE_ALPHA64 ||
		pFileHdr->Machine == IMAGE_FILE_MACHINE_AMD64) {
	    __try {
		patch_obj(pFileHdr);
	    }
	    __except(1) {
		LOG("Exception while patching OBJ");
	    }
	}
    }
}

// DSB - Added this for a cleaner API namespace.
VOID
unstamp_mapped_file(LPVOID p_baseAddress)
{
    patch_mapped_file(p_baseAddress);
}
