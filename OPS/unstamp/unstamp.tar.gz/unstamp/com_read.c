/* 
 * Copyright (C) 2006 David Boyce.  All rights reserved.
 * Based on code purchased via RentACoder.com (Request Id 401892).
 *
 * This program is free software; you may redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
	Description:
		Functions for reading and patching metadata table rows
**/

#include "com.h"
#include "com_read.h"
#include "com_types.h"

/**
* Read an index using the calculated size of the index type
* IN: 'p_typeID' index type id
* IN/OUT: 'p_bytePtr' pointer to metadata
* RET: value read. either a WORD or DWORD
*/
DWORD
read_index(INT p_typeID, PBYTE * p_bytePtr)
{
    DWORD numToRead = g_types[p_typeID].BytesNeeded;
    if (numToRead == 2)
	return read_word(p_bytePtr);
    else if (numToRead == 4)
	return read_dword(p_bytePtr);
    return 0;
}

/**
* Read a stream header
* IN/OUT: 'p_bytePtr' pointer to metadata
* RET: pointer to stream header read
*/
PSTREAM_HEADER
read_stream_header(PBYTE * p_bytePtr)
{
    PSTREAM_HEADER headPtr = (PSTREAM_HEADER) (*p_bytePtr);
    size_t size;
    (*p_bytePtr) += 8;
    size = strlen(&headPtr->Name[0]);
    size += (4 - (size % 4));
    (*p_bytePtr) += size;
    return headPtr;
}

/**
* Read a string from string heap
* IN: 'p_offset' offset into string heap
* RET: string at offset
*/
PCSTR
read_heap_string(DWORD p_offset)
{
    return (g_StringsPtr + p_offset);
}

/**
* Read a string offset
* IN/OUT: 'p_bytePtr' pointer to metadata
* RET: offset read.
*/
DWORD
read_string_offset(PBYTE * p_bytePtr)
{
    return (DWORD) (g_StringOffsetSize ==
	    2) ? read_word(p_bytePtr) : read_dword(p_bytePtr);
}

/**
* Read a blob offset
* IN/OUT: 'p_bytePtr' pointer to metadata
* RET: offset read.
*/
DWORD
read_blob_offset(PBYTE * p_bytePtr)
{
    return (DWORD) (g_BlobOffsetSize ==
	    2) ? read_word(p_bytePtr) : read_dword(p_bytePtr);
}

/**
* Read a GUID offset
* IN/OUT: 'p_bytePtr' pointer to metadata
* RET: offset read.
*/
DWORD
read_GUID_offset(PBYTE * p_bytePtr)
{
    return (DWORD) (g_GUIDOffsetSize ==
	    2) ? read_word(p_bytePtr) : read_dword(p_bytePtr);
}

/**
* Seek a number of bytes into metadata
* IN/OUT: 'p_bytePtr' pointer to metadata
*/
VOID
seek_bytes(PBYTE * p_bytePtr, INT p_num)
{
    (*p_bytePtr) = (*p_bytePtr) + p_num;
}

/**
* Read a byte of metadata
* IN/OUT: 'p_bytePtr' pointer to metadata
* RET: byte read
*/
BYTE
read_byte(PBYTE * p_bytePtr)
{
    BYTE byte = *((PBYTE) (*p_bytePtr));
    (*p_bytePtr)++;
    return byte;
}

/**
* Read a word of metadata
* IN/OUT: 'p_bytePtr' pointer to metadata
* RET: word read
*/
WORD
read_word(PBYTE * p_bytePtr)
{
    WORD word = *((PWORD) (*p_bytePtr));
    (*p_bytePtr) = (*p_bytePtr) + 2;
    return word;
}

/**
* Patch a word of metadata
* IN/OUT: 'p_bytePtr' pointer to metadata
* RET: word read
*/
WORD
patch_word(PBYTE * p_bytePtr, WORD p_value)
{
    PWORD pWord = (PWORD) (*p_bytePtr);
    WORD word = *pWord;

    *pWord = p_value;

    (*p_bytePtr) = (*p_bytePtr) + 2;
    return word;
}

/**
* read a dword of metadata
* IN/OUT: 'p_bytePtr' pointer to metadata
* RET: dword read
*/
DWORD
read_dword(PBYTE * p_bytePtr)
{
    DWORD dword = *((PDWORD) (*p_bytePtr));
    (*p_bytePtr) = (*p_bytePtr) + 4;
    return dword;
}

/**
* The following functions are for reading rows of certain tables
* and they all have the same number of arguments.
* IN/OUT: 'p_bytePtr' pointer to metadata
*/
VOID
read_Module_TableRow(PBYTE * p_bytePtr)
{
    WORD Generation;
    DWORD Name;
    DWORD Mvid;
    DWORD EncId;
    DWORD EncBaseId;

    Generation = read_word(p_bytePtr);
    Name = read_string_offset(p_bytePtr);
    Mvid = read_GUID_offset(p_bytePtr);
    EncId = read_GUID_offset(p_bytePtr);
    EncBaseId = read_GUID_offset(p_bytePtr);

    LOGPTR(Generation);
    LOGPTR(Name);
    LOGPTR(Mvid);
    LOGPTR(EncId);
    LOGPTR(EncBaseId);
}

VOID
read_TypeRef_TableRow(PBYTE * p_bytePtr)
{
    DWORD ResolutionScope;
    DWORD TypeName;
    DWORD TypeNamespace;

    ResolutionScope = read_index(eResolutionScope, p_bytePtr);
    TypeName = read_string_offset(p_bytePtr);
    TypeNamespace = read_string_offset(p_bytePtr);

    LOGPTR(ResolutionScope);
    LOGSTR(read_heap_string(TypeName));
    LOGSTR(read_heap_string(TypeNamespace));
}

VOID
read_TypeDef_TableRow(PBYTE * p_bytePtr)
{
    DWORD Flags;
    DWORD TypeName;
    DWORD TypeNamespace;
    DWORD Extends;
    DWORD FieldList;
    DWORD MethodList;

    Flags = read_dword(p_bytePtr);
    TypeName = read_string_offset(p_bytePtr);
    TypeNamespace = read_string_offset(p_bytePtr);
    Extends = read_index(eTypeDefOrRef, p_bytePtr);
    FieldList = read_index(eFieldDef, p_bytePtr);
    MethodList = read_index(eMethodDef, p_bytePtr);


    LOGPTR(Flags);
    LOGSTR(read_heap_string(TypeName));
    LOGSTR(read_heap_string(TypeNamespace));
    LOGPTR(Extends);
    LOGPTR(FieldList);
    LOGPTR(MethodList);

}

VOID
read_Field_TableRow(PBYTE * p_bytePtr)
{
    DWORD Flags;
    DWORD Name;
    DWORD Signature;

    Flags = read_word(p_bytePtr);
    Name = read_string_offset(p_bytePtr);
    Signature = read_blob_offset(p_bytePtr);

    LOGPTR(Flags);
    LOGSTR(read_heap_string(Name));
    LOGPTR(Signature);
}

VOID
read_MethodDef_TableRow(PBYTE * p_bytePtr)
{
    DWORD RVA;
    DWORD ImplFlags;
    DWORD Flags;
    DWORD Name;
    DWORD Signature;
    DWORD ParamList;

    RVA = read_dword(p_bytePtr);
    ImplFlags = read_word(p_bytePtr);
    Flags = read_word(p_bytePtr);
    Name = read_string_offset(p_bytePtr);
    Signature = read_blob_offset(p_bytePtr);
    ParamList = read_index(eParamDef, p_bytePtr);

    LOGPTR(RVA);
    LOGPTR(Flags);
    LOGPTR(ImplFlags);
    LOGSTR(read_heap_string(Name));
    LOGPTR(Signature);
    LOGPTR(ParamList);
}

VOID
read_Param_TableRow(PBYTE * p_bytePtr)
{
    WORD Flags;
    WORD Sequence;
    DWORD Name;

    Flags = read_word(p_bytePtr);
    Sequence = read_word(p_bytePtr);
    Name = read_string_offset(p_bytePtr);

    LOGPTR(Flags);
    LOGPTR(Sequence);
    LOGSTR(read_heap_string(Name));
}

VOID
read_InterfaceImpl_TableRow(PBYTE * p_bytePtr)
{
    DWORD Class;
    DWORD Interface;

    Class = read_index(eTypeDef, p_bytePtr);
    Interface = read_index(eTypeDefOrRef, p_bytePtr);

    LOGPTR(Class);
    LOGPTR(Interface);
}

VOID
read_MemberRef_TableRow(PBYTE * p_bytePtr)
{
    DWORD Class;
    DWORD Name;
    DWORD Signature;

    Class = read_index(eMemberRefParent, p_bytePtr);
    Name = read_string_offset(p_bytePtr);
    Signature = read_blob_offset(p_bytePtr);

    LOGPTR(Class);
    LOGSTR(read_heap_string(Name));
    LOGPTR(Signature);
}

VOID
read_Constant_TableRow(PBYTE * p_bytePtr)
{
    WORD Type;
    DWORD Parent;
    DWORD Value;

    Type = read_word(p_bytePtr);
    Parent = read_index(eHasConstant, p_bytePtr);
    Value = read_blob_offset(p_bytePtr);

    LOGPTR(Type);
    LOGPTR(Parent);
    LOGPTR(Value);
}

VOID
read_CustomAttribute_TableRow(PBYTE * p_bytePtr)
{
    DWORD Parent;
    DWORD Type;
    DWORD Value;

    Parent = read_index(eHasCustomAttribute, p_bytePtr);
    Type = read_index(eCustomAttributeType, p_bytePtr);
    Value = read_blob_offset(p_bytePtr);

    LOGPTR(Type);
    LOGPTR(Parent);
    LOGPTR(Value);
}

VOID
read_FieldMarshal_TableRow(PBYTE * p_bytePtr)
{
    DWORD Parent;
    DWORD NativeType;

    Parent = read_index(eHasFieldMarshal, p_bytePtr);
    NativeType = read_blob_offset(p_bytePtr);

    LOGPTR(Parent);
    LOGPTR(NativeType);
}

VOID
read_DeclSecurity_TableRow(PBYTE * p_bytePtr)
{
    WORD Action;
    DWORD Parent;
    DWORD PermissionSet;

    Action = read_word(p_bytePtr);
    Parent = read_index(eHasDeclSecurity, p_bytePtr);
    PermissionSet = read_blob_offset(p_bytePtr);

    LOGPTR(Action);
    LOGPTR(Parent);
    LOGPTR(PermissionSet);
}

VOID
read_ClassLayout_TableRow(PBYTE * p_bytePtr)
{
    WORD PackingSize;
    DWORD ClassSize;
    DWORD Parent;

    PackingSize = read_word(p_bytePtr);
    ClassSize = read_dword(p_bytePtr);
    Parent = read_index(eTypeDef, p_bytePtr);

    LOGPTR(PackingSize);
    LOGPTR(ClassSize);
    LOGPTR(Parent);
}

VOID
read_FieldLayout_TableRow(PBYTE * p_bytePtr)
{
    DWORD Offset;
    DWORD Field;

    Offset = read_dword(p_bytePtr);
    Field = read_index(eFieldDef, p_bytePtr);

    LOGPTR(Offset);
    LOGPTR(Field);
}

VOID
read_StandAloneSig_TableRow(PBYTE * p_bytePtr)
{
    DWORD Signature;

    Signature = read_blob_offset(p_bytePtr);

    LOGPTR(Signature);
}

VOID
read_EventMap_TableRow(PBYTE * p_bytePtr)
{
    DWORD Parent;
    DWORD EventList;

    Parent = read_index(eTypeDef, p_bytePtr);
    EventList = read_index(eEvent, p_bytePtr);

    LOGPTR(Parent);
    LOGPTR(EventList);
}

VOID
read_Event_TableRow(PBYTE * p_bytePtr)
{
    DWORD EventFlags;
    DWORD Name;
    DWORD EventType;

    EventFlags = read_word(p_bytePtr);
    Name = read_string_offset(p_bytePtr);
    EventType = read_index(eTypeDefOrRef, p_bytePtr);

    LOGPTR(EventFlags);
    LOGSTR(read_heap_string(Name));
    LOGPTR(EventType);
}

VOID
read_PropertyMap_TableRow(PBYTE * p_bytePtr)
{
    DWORD Parent;
    DWORD PropertyList;

    Parent = read_index(eTypeDef, p_bytePtr);
    PropertyList = read_index(eProperty, p_bytePtr);

    LOGPTR(Parent);
    LOGPTR(PropertyList);
}

VOID
read_Property_TableRow(PBYTE * p_bytePtr)
{
    WORD Flags;
    DWORD Name;
    DWORD Type;

    Flags = read_word(p_bytePtr);
    Name = read_string_offset(p_bytePtr);
    Type = read_blob_offset(p_bytePtr);

    LOGPTR(Flags);
    LOGSTR(read_heap_string(Name));
    LOGPTR(Type);
}

VOID
read_MethodSemantics_TableRow(PBYTE * p_bytePtr)
{
    WORD Semantics;
    DWORD Method;
    DWORD Association;

    Semantics = read_word(p_bytePtr);
    Method = read_index(eMethodDef, p_bytePtr);
    Association = read_index(eHasSemantics, p_bytePtr);

    LOGPTR(Semantics);
    LOGPTR(Method);
    LOGPTR(Association);
}

VOID
read_MethodImpl_TableRow(PBYTE * p_bytePtr)
{
    DWORD Class;
    DWORD MethodBody;
    DWORD MethodDeclaration;

    Class = read_index(eTypeDef, p_bytePtr);
    MethodBody = read_index(eMethodDefOrRef, p_bytePtr);
    MethodDeclaration = read_index(eMethodDefOrRef, p_bytePtr);

    LOGPTR(Class);
    LOGPTR(MethodBody);
    LOGPTR(MethodDeclaration);
}

VOID
read_ModuleRef_TableRow(PBYTE * p_bytePtr)
{
    DWORD Name;

    Name = read_string_offset(p_bytePtr);

    LOGSTR(read_heap_string(Name));
}

VOID
read_TypeSpec_TableRow(PBYTE * p_bytePtr)
{
    DWORD Signature;

    Signature = read_blob_offset(p_bytePtr);

    LOGPTR(Signature);
}

VOID
read_ImplMap_TableRow(PBYTE * p_bytePtr)
{
    WORD MappingFlags;
    DWORD MemberForwarded;
    DWORD ImportName;
    DWORD ImportScope;

    MappingFlags = read_word(p_bytePtr);
    MemberForwarded = read_index(eMemberForwarded, p_bytePtr);
    ImportName = read_string_offset(p_bytePtr);
    ImportScope = read_index(eModuleRef, p_bytePtr);

    LOGPTR(MappingFlags);
    LOGPTR(MemberForwarded);
    LOGSTR(read_heap_string(ImportName));
    LOGPTR(ImportScope);
}

VOID
read_FieldRVA_TableRow(PBYTE * p_bytePtr)
{
    DWORD RVA;
    DWORD Field;

    RVA = read_dword(p_bytePtr);
    Field = read_index(eFieldDef, p_bytePtr);

    LOGPTR(RVA);
    LOGPTR(Field);
}

VOID
read_Assembly_TableRow(PBYTE * p_bytePtr)
{
    DWORD HashAlgId;
    WORD MajorVersion;
    WORD MinorVersion;
    WORD BuildNumber;
    WORD RevisionNumber;
    DWORD Flags;
    DWORD PublicKey;
    DWORD Name;
    DWORD Culture;

    HashAlgId = read_dword(p_bytePtr);
    MajorVersion = read_word(p_bytePtr);
    MinorVersion = read_word(p_bytePtr);
    BuildNumber = patch_word(p_bytePtr, 0x0000);	// Patch this!
    RevisionNumber = patch_word(p_bytePtr, 0x0000);	// Patch this!
    Flags = read_dword(p_bytePtr);
    PublicKey = read_blob_offset(p_bytePtr);
    Name = read_string_offset(p_bytePtr);
    Culture = read_string_offset(p_bytePtr);

    LOGPTR(HashAlgId);
    LOGPTR(MajorVersion);
    LOGPTR(MinorVersion);
    LOGPTR(BuildNumber);
    LOGPTR(RevisionNumber);
    LOGPTR(Flags);
    LOGPTR(PublicKey);
    LOGSTR(read_heap_string(Name));
    LOGSTR(read_heap_string(Culture));
}

VOID
read_AssemblyProcessor_TableRow(PBYTE * p_bytePtr)
{
    DWORD Processor;
    Processor = read_dword(p_bytePtr);

    LOGPTR(Processor);
}

VOID
read_AssemblyOS_TableRow(PBYTE * p_bytePtr)
{
    DWORD OSPlatformID;
    DWORD OSMajorVersion;
    DWORD OSMinorVersion;

    OSPlatformID = read_dword(p_bytePtr);
    OSMajorVersion = read_dword(p_bytePtr);
    OSMinorVersion = read_dword(p_bytePtr);

    LOGPTR(OSPlatformID);
    LOGPTR(OSMajorVersion);
    LOGPTR(OSMinorVersion);
}

VOID
read_AssemblyRef_TableRow(PBYTE * p_bytePtr)
{
    WORD MajorVersion;
    WORD MinorVersion;
    WORD BuildNumber;
    WORD RevisionNumber;
    DWORD Flags;
    DWORD PublicKeyOrToken;
    DWORD Name;
    DWORD Culture;
    DWORD HashValue;

    MajorVersion = read_word(p_bytePtr);
    MinorVersion = read_word(p_bytePtr);
    BuildNumber = read_word(p_bytePtr);
    RevisionNumber = read_word(p_bytePtr);
    Flags = read_dword(p_bytePtr);
    PublicKeyOrToken = read_blob_offset(p_bytePtr);
    Name = read_string_offset(p_bytePtr);
    Culture = read_string_offset(p_bytePtr);
    HashValue = read_blob_offset(p_bytePtr);

    LOGPTR(MajorVersion);
    LOGPTR(MinorVersion);
    LOGPTR(BuildNumber);
    LOGPTR(RevisionNumber);
    LOGPTR(Flags);
    LOGPTR(PublicKeyOrToken);
    LOGSTR(read_heap_string(Name));
    LOGSTR(read_heap_string(Culture));
    LOGPTR(HashValue);
}

VOID
read_File_TableRow(PBYTE * p_bytePtr)
{
    DWORD Flags;
    DWORD Name;
    DWORD HashValue;

    Flags = read_dword(p_bytePtr);
    Name = read_string_offset(p_bytePtr);
    HashValue = read_blob_offset(p_bytePtr);

    LOGPTR(Flags);
    LOGSTR(read_heap_string(Name));
    LOGPTR(HashValue);
}

VOID
read_ExportedType_TableRow(PBYTE * p_bytePtr)
{
    DWORD Flags;
    DWORD TypeDefId;
    DWORD TypeName;
    DWORD TypeNamespace;
    DWORD Implementation;

    Flags = read_dword(p_bytePtr);
    TypeDefId = read_dword(p_bytePtr);
    TypeName = read_string_offset(p_bytePtr);
    TypeNamespace = read_string_offset(p_bytePtr);
    Implementation = read_index(eImplementation, p_bytePtr);

    LOGPTR(Flags);
    LOGPTR(TypeDefId);
    LOGSTR(read_heap_string(TypeName));
    LOGSTR(read_heap_string(TypeNamespace));
    LOGPTR(Implementation);
}

VOID
read_ManifestResource_TableRow(PBYTE * p_bytePtr)
{
    DWORD Offset;
    DWORD Flags;
    DWORD Name;
    DWORD Implementation;

    Offset = read_dword(p_bytePtr);
    Flags = read_dword(p_bytePtr);
    Name = read_string_offset(p_bytePtr);
    Implementation = read_index(eImplementation, p_bytePtr);

    LOGPTR(Offset);
    LOGPTR(Flags);
    LOGSTR(read_heap_string(Name));
    LOGPTR(Implementation);
}

VOID
read_NestedClass_TableRow(PBYTE * p_bytePtr)
{
    DWORD NestedClass;
    DWORD EnclosingClass;

    NestedClass = read_index(eTypeDef, p_bytePtr);
    EnclosingClass = read_index(eTypeDef, p_bytePtr);

    LOGPTR(NestedClass);
    LOGPTR(EnclosingClass);
}
