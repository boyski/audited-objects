#!/bin/sh
autoconf
rm -rf autom4te.cache
