/* 
 * Copyright (C) 2006 David Boyce.  All rights reserved.
 * Based on code purchased via RentACoder.com (Request Id 401892).
 *
 * This program is free software; you may redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
	Description:
		Patch the load configuration directory
**/

#include "loadconfig.h"
#include "patch.h"

/**
* Patch the load configuration directory
* RET: TRUE if sucess, else FALSE
*/
BOOL
patch_loadconfig()
{
    PIMAGE_DATA_DIRECTORY pDataDir = NULL;
    PIMAGE_LOAD_CONFIG_DIRECTORY pCfgDir = NULL;
    /* get data directroy entry */
    pDataDir = get_data_dir(IMAGE_DIRECTORY_ENTRY_LOAD_CONFIG);
    if (pDataDir == NULL || pDataDir->Size == 0)
	return FALSE;
    /* get load config directory pointer */
    pCfgDir =
	    (PIMAGE_LOAD_CONFIG_DIRECTORY) rva_to_ptr(pDataDir->
	    VirtualAddress);
    if (pCfgDir == NULL) {
	LOG("rva_to_ptr failed - patch_loadconfig");
	return FALSE;
    }
    /* Patch it! */
    LOGPTR(pCfgDir->TimeDateStamp);
    pCfgDir->TimeDateStamp = 0;

    return TRUE;
}
