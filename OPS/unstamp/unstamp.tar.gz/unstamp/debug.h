/* 
 * Copyright (C) 2006 David Boyce.  All rights reserved.
 * Based on code purchased via RentACoder.com (Request Id 401892).
 *
 * This program is free software; you may redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
	Description:
		Patch the debug directory
**/

#ifndef DEBUG_H_37734534
#define DEBUG_H_37734534

#include "common.h"

/* CodeView signatures. */
#define		CV_TYPE_NV09		0x3930424E	// NB09         Debuginfo in EXE
#define		CV_TYPE_NV10		0x3031424E	// NB10         VC 6.0          external PDB 2.0 file
#define		CV_TYPE_NV11		0x3131424E	// NB11         Debuginfo in EXE
#define		CV_TYPE_RSDS		0x53445352	// RSDS         VC .NET         external PDB 7.0 file

/* PDB 2.0 file */
typedef struct t_PDB20 {
    DWORD Signature;
    DWORD Offset;
    DWORD TimeDateStamp;
    DWORD Age;
    BYTE PDBFileName[1];
} PDB20, *PPDB20;

/* PDB 7.0 file */
typedef struct t_PDB70 {
    DWORD Signature;
    DWORD ID_A;
    DWORD ID_B;
    DWORD ID_C;
    DWORD ID_D;
    DWORD Age;
    BYTE PDBFileName[1];
} PDB70, *PPDB70;

/**
* Patch the debug directory
* RET: TRUE if sucess, else FALSE
*/
BOOL patch_debug();

#endif
