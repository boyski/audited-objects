/* 
 * Copyright (C) 2006 David Boyce.  All rights reserved.
 * Based on code purchased via RentACoder.com (Request Id 401892).
 *
 * This program is free software; you may redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
	Description:
		Patch the debug directory
**/

#include <time.h>
#include "debug.h"
#include "patch.h"
/* possible debug directory types */
static char *debugType[12] = {
    "IMAGE_DEBUG_TYPE_UNKNOWN",
    "IMAGE_DEBUG_TYPE_COFF",
    "IMAGE_DEBUG_TYPE_CODEVIEW",
    "IMAGE_DEBUG_TYPE_FPO",
    "IMAGE_DEBUG_TYPE_MISC",
    "IMAGE_DEBUG_TYPE_EXCEPTION",
    "IMAGE_DEBUG_TYPE_FIXUP",
    "IMAGE_DEBUG_TYPE_OMAP_TO_SRC",
    "IMAGE_DEBUG_TYPE_OMAP_FROM_SRC",
    "IMAGE_DEBUG_TYPE_BORLAND",
    "IMAGE_DEBUG_TYPE_RESERVED10",
    "IMAGE_DEBUG_TYPE_CLSID"
};

/**
* Patch a CodeView debug directory
* IN: 'p_pCV' pointer to CV dir
*/
VOID
patch_debug_cv(LPVOID p_pCV)
{
    DWORD signature;
    signature = *((LPDWORD) p_pCV);

    LOGSTRPTR("CodeView Signature:", signature);

    if (signature == CV_TYPE_NV10) {
	PPDB20 info = (PPDB20) p_pCV;
	LOGSTR(info->PDBFileName);
	/* Patch it */
	info->TimeDateStamp = 0;
	info->Age = 0;
    } else if (signature == CV_TYPE_RSDS) {
	PPDB70 info = (PPDB70) p_pCV;
	LOGSTR(info->PDBFileName);
	/* Patch it */
	info->ID_A = info->ID_B = info->ID_C = info->ID_D = 0;
	info->Age = 0;
    } else if (signature == CV_TYPE_NV09) {
    } else if (signature == CV_TYPE_NV11) {
    } else {
	LOG("Unknown CodeView signature");
    }
}

/**
* Patch the debug directory
* RET: TRUE if sucess, else FALSE
*/
BOOL
patch_debug()
{
    PIMAGE_DATA_DIRECTORY pDataDir = NULL;
    PIMAGE_DEBUG_DIRECTORY pDebugDir = NULL;
    DWORD num, i;
    /* get data directory entry */
    pDataDir = get_data_dir(IMAGE_DIRECTORY_ENTRY_DEBUG);
    if (pDataDir == NULL || pDataDir->Size == 0)
	return FALSE;
    /* get pointer to first debug directory */
    pDebugDir =
	    (PIMAGE_DEBUG_DIRECTORY) rva_to_ptr(pDataDir->VirtualAddress);
    if (pDebugDir == NULL)
	return FALSE;
    /* iterate trough all the debug directories */
    num = pDataDir->Size / sizeof(IMAGE_DEBUG_DIRECTORY);
    for (i = 0; i < num; i++, pDebugDir++) {
	LOGPTR(pDebugDir->TimeDateStamp);
	LOGSTRPTR(debugType[pDebugDir->Type], pDebugDir->Type);
	/* Patch it */
	pDebugDir->TimeDateStamp = 0;

	switch (pDebugDir->Type) {
	    case IMAGE_DEBUG_TYPE_CODEVIEW:
		patch_debug_cv(MAKE_PTR(PVOID, g_baseAddr,
				pDebugDir->PointerToRawData));
		break;
	    case IMAGE_DEBUG_TYPE_COFF:
		break;
	    default:
		break;
	};
    }

    return TRUE;
}
