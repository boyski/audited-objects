// gcc -g -W -Wall -I. -o tlist tlist.c -L/vobs_ao/client/OPS/$PLATFORM/lib -lkaz-dbg

#include "list.h"
#include "dict.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

void
dict_callback(dict_t *dictp, dnode_t *dnp, void *ctxp)
{
    char *str;

    if (ctxp != ctxp)
	return;

    dict_delete(dictp, dnp);

    str = (char *)dnode_getkey(dnp);

    printf("=%s\n", str);

    free(str);
}

void
list_callback(list_t *listp, lnode_t *lnp, void *ctxp)
{
    dict_t *dictp;

    if (ctxp != ctxp)
	return;

    list_delete(listp, lnp);

    dictp = (dict_t *)lnode_get(lnp);

    dict_process(dictp, NULL, (dnode_process_t)dict_callback);

    dict_destroy(dictp);
}

int
main(int argc, char *argv[])
{
    list_t *listp;
    lnode_t *lnp;
    int i;

    listp = list_create(LISTCOUNT_T_MAX);

    for (i = 1; i < argc; i++) {
	dict_t *dictp;
	char *ap;

	dictp = dict_create(DICTCOUNT_T_MAX, (dict_comp_t) strcmp);

	for (ap = argv[i]; *ap; ap++) {
	    dict_alloc_insert(dictp, strdup(ap), NULL);
	}

	lnp = lnode_create(dictp);

	list_append(listp, lnp);
    }

    list_process(listp, NULL, list_callback);

    printf("List contains %ld members\n", list_count(listp));

    list_destroy(listp);

    return 0;
}
