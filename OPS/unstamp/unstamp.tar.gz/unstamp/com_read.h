/* 
 * Copyright (C) 2006 David Boyce.  All rights reserved.
 * Based on code purchased via RentACoder.com (Request Id 401892).
 *
 * This program is free software; you may redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
	Description:
		Functions for reading and patching metadata table rows
**/

#ifndef COM_READ_H_37734534
#define COM_READ_H_37734534

#include "common.h"
/**
* Read a stream header
* IN/OUT: 'p_bytePtr' pointer to metadata
* RET: pointer to stream header read
*/
PSTREAM_HEADER read_stream_header(PBYTE * p_bytePtr);
/**
* Seek a number of bytes into metadata
* IN/OUT: 'p_bytePtr' pointer to metadata
*/
VOID seek_bytes(PBYTE * p_bytePtr, INT p_num);
/**
* Read a byte of metadata
* IN/OUT: 'p_bytePtr' pointer to metadata
* RET: byte read
*/
BYTE read_byte(PBYTE * p_bytePtr);
/**
* Read a word of metadata
* IN/OUT: 'p_bytePtr' pointer to metadata
* RET: word read
*/
WORD read_word(PBYTE * p_bytePtr);
/**
* read a dword of metadata
* IN/OUT: 'p_bytePtr' pointer to metadata
* RET: dword read
*/
DWORD read_dword(PBYTE * p_bytePtr);
/**
* Read an index using the calculated size of the index type
* IN: 'p_typeID' index type id
* IN/OUT: 'p_bytePtr' pointer to metadata
* RET: value read. either a WORD or DWORD
*/
DWORD read_index(INT p_typeID, PBYTE * p_bytePtr);

/**
* The following functions are for reading rows of certain tables
* and they all have the same number of arguments.
* IN/OUT: 'p_bytePtr' pointer to metadata
*/
VOID read_Module_TableRow(PBYTE * p_bytePtr);
VOID read_TypeRef_TableRow(PBYTE * p_bytePtr);
VOID read_TypeDef_TableRow(PBYTE * p_bytePtr);
VOID read_Field_TableRow(PBYTE * p_bytePtr);
VOID read_MethodDef_TableRow(PBYTE * p_bytePtr);
VOID read_Param_TableRow(PBYTE * p_bytePtr);
VOID read_InterfaceImpl_TableRow(PBYTE * p_bytePtr);
VOID read_MemberRef_TableRow(PBYTE * p_bytePtr);
VOID read_Constant_TableRow(PBYTE * p_bytePtr);
VOID read_CustomAttribute_TableRow(PBYTE * p_bytePtr);
VOID read_FieldMarshal_TableRow(PBYTE * p_bytePtr);
VOID read_DeclSecurity_TableRow(PBYTE * p_bytePtr);
VOID read_ClassLayout_TableRow(PBYTE * p_bytePtr);
VOID read_FieldLayout_TableRow(PBYTE * p_bytePtr);
VOID read_StandAloneSig_TableRow(PBYTE * p_bytePtr);
VOID read_EventMap_TableRow(PBYTE * p_bytePtr);
VOID read_Event_TableRow(PBYTE * p_bytePtr);
VOID read_PropertyMap_TableRow(PBYTE * p_bytePtr);
VOID read_Property_TableRow(PBYTE * p_bytePtr);
VOID read_MethodSemantics_TableRow(PBYTE * p_bytePtr);
VOID read_MethodImpl_TableRow(PBYTE * p_bytePtr);
VOID read_ModuleRef_TableRow(PBYTE * p_bytePtr);
VOID read_TypeSpec_TableRow(PBYTE * p_bytePtr);
VOID read_ImplMap_TableRow(PBYTE * p_bytePtr);
VOID read_FieldRVA_TableRow(PBYTE * p_bytePtr);
VOID read_Assembly_TableRow(PBYTE * p_bytePtr);
VOID read_AssemblyProcessor_TableRow(PBYTE * p_bytePtr);
VOID read_AssemblyOS_TableRow(PBYTE * p_bytePtr);
VOID read_AssemblyRef_TableRow(PBYTE * p_bytePtr);
VOID read_File_TableRow(PBYTE * p_bytePtr);
VOID read_ExportedType_TableRow(PBYTE * p_bytePtr);
VOID read_ManifestResource_TableRow(PBYTE * p_bytePtr);
VOID read_NestedClass_TableRow(PBYTE * p_bytePtr);

#endif
