/* 
 * Copyright (C) 2006 David Boyce.  All rights reserved.
 * Based on code purchased via RentACoder.com (Request Id 401892).
 *
 * This program is free software; you may redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
	Description:
		Definitions and structures for reading meta data tables types
**/

#ifndef COM_TYPES_H_37734534
#define COM_TYPES_H_37734534

#include "common.h"

/* meta data table defines  */
#define MODULE					0
#define TYPEREF					1
#define TYPEDEF					2
#define FIELD					4
#define FIELDDEF				4
#define METHODDEF				6
#define PARAM					8
#define PARAMDEF				8
#define INTERFACEIMPL			9
#define MEMBERREF				10
#define CONSTANT				11
#define CUSTOMATTRIBUTE			12
#define FIELDMARSHAL			13
#define DECLSECURITY			14
#define CLASSLAYOUT				15
#define FIELDLAYOUT				16
#define STANDALONESIG			17
#define EVENTMAP				18
#define EVENT					20
#define PROPERTYMAP				21
#define PROPERTY				23
#define METHODSEMANTICS			24
#define METHODIMPL				25
#define MODULEREF				26
#define TYPESPEC				27
#define IMPLMAP					28
#define FIELDRVA				29
#define ASSEMBLY				32
#define ASSEMBLYPROCESSOR		33
#define ASSEMBLYOS				34
#define ASSEMBLYREF				35
#define ASSEMBLYREFPROCESSOR	36
#define ASSEMBLYREFOS			37
#define FILE					38
#define EXPORTEDTYPE			39
#define MANIFESTRESOURCE		40
#define NESTEDCLASS				41
#define UNUSED					64	//@@

/* metadata table entry type struct */
typedef struct t_IndexType {
    INT TypeIDs[32];
    BYTE NumIDs;
    BYTE BytesNeeded;

} TYPEINDEX, *PTYPEINDEX;

#define NUM_INDEX_TYPES			30

/* info struct for a metadata table */
typedef struct t_TableInfo {
    DWORD NumRows;
    DWORD RowSize;
    LPCSTR Name;
} TABLE_INFO, *PTABLE_INFO;

/* metadata table entry type enumerations */
enum enum_Types {
    eTypeDef,
    eTypeRef,
    eTypeSpec,
    eFieldDef,
    eParamDef,
    eProperty,
    eMethodDef,
    eInterfaceImpl,
    eMemberRef,
    eModule,
    eEvent,
    eStandAloneSig,
    eModuleRef,
    eAssembly,
    eAssemblyRef,
    eFile,
    eExportedType,
    eManifestResource,
    eTypeDefOrRef,
    eHasConstant,
    eHasCustomAttribute,
    eHasFieldMarshal,
    eHasDeclSecurity,
    eMemberRefParent,
    eHasSemantics,
    eMethodDefOrRef,
    eMemberForwarded,
    eImplementation,
    eCustomAttributeType,
    eResolutionScope,
};

/* external data */
extern TYPEINDEX g_types[];
extern TABLE_INFO g_tableInfo[];

#endif
