/* 
 * Copyright (C) 2006 David Boyce.  All rights reserved.
 * Based on code purchased via RentACoder.com (Request Id 401892).
 *
 * This program is free software; you may redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
	Description:
		Definitions and structures for reading meta data tables types
**/

#include "com_types.h"

/* 
	metadata table information. 
	65 of them, not all are used 
*/
TABLE_INFO g_tableInfo[] = {
    {0, 0, "Module"}
    ,				// 0
    {0, 0, "TypeRef"}
    ,				// 1
    {0, 0, "TypeDef"}
    ,				// 2
    {0, 0, ""}
    ,
    {0, 0, "Field"}
    ,				// 4
    {0, 0, ""}
    ,
    {0, 0, "MethodDef"}
    ,				// 6
    {0, 0, ""}
    ,
    {0, 0, "Param"}
    ,				// 8
    {0, 0, "InterfaceImpl"}
    ,				// 9
    {0, 0, "MemberRef"}
    ,				// 10
    {0, 0, "Constant"}
    ,				// 11
    {0, 0, "CustomAttribute"}
    ,				// 12
    {0, 0, "FieldMarshal"}
    ,				// 13
    {0, 0, "DeclSecurity"}
    ,				// 14
    {0, 0, "ClassLayout"}
    ,				// 15
    {0, 0, "FieldLayout"}
    ,				// 16
    {0, 0, "StandAloneSig"}
    ,				// 17
    {0, 0, "EventMap"}
    ,				// 18
    {0, 0, ""}
    ,
    {0, 0, "Event"}
    ,				// 20
    {0, 0, "PropertyMap"}
    ,				// 21
    {0, 0, ""}
    ,
    {0, 0, "Property"}
    ,				// 23
    {0, 0, "MethodSemantics"}
    ,				// 24
    {0, 0, "MethodImpl"}
    ,				// 25
    {0, 0, "ModuleRef"}
    ,				// 26
    {0, 0, "TypeSpec"}
    ,				// 27
    {0, 0, "ImplMap"}
    ,				// 28
    {0, 0, "FieldRVA"}
    ,				// 29
    {0, 0, ""}
    ,
    {0, 0, ""}
    ,
    {0, 0, "Assembly"}
    ,				// 32
    {0, 0, "AssemblyProcessor"}
    ,				// 33
    {0, 0, "AssemblyOS"}
    ,				// 34
    {0, 0, "AssemblyRef"}
    ,				// 35
    {0, 0, "AssemblyRefProcessor"}
    ,				// 36
    {0, 0, "AssemblyRefOS"}
    ,				// 37
    {0, 0, "File"}
    ,				// 38
    {0, 0, "ExportedType"}
    ,				// 39
    {0, 0, "ManifestResource"}
    ,				// 40
    {0, 0, "NestedClass"}
    ,				// 41
    {0, 0, ""}
    , {0, 0, ""}
    , {0, 0, ""}
    , {0, 0, ""}
    , {0, 0, ""}
    , {0, 0, ""}
    , {0, 0, ""}
    , {0, 0, ""}
    ,
    {0, 0, ""}
    , {0, 0, ""}
    , {0, 0, ""}
    , {0, 0, ""}
    , {0, 0, ""}
    , {0, 0, ""}
    , {0, 0, ""}
    , {0, 0, ""}
    ,
    {0, 0, ""}
    , {0, 0, ""}
    , {0, 0, ""}
    , {0, 0, ""}
    , {0, 0, ""}
};

/* metadata table entry types, matches enums in header*/
TYPEINDEX g_types[] = {
    {{TYPEDEF}
	    , 1, 0}
    ,
    {{TYPEREF}
	    , 1, 0}
    ,
    {{TYPESPEC}
	    , 1, 0}
    ,
    {{FIELDDEF}
	    , 1, 0}
    ,
    {{PARAMDEF}
	    , 1, 0}
    ,
    {{PROPERTY}
	    , 1, 0}
    ,
    {{METHODDEF}
	    , 1, 0}
    ,
    {{INTERFACEIMPL}
	    , 1, 0}
    ,
    {{MEMBERREF}
	    , 1, 0}
    ,
    {{MODULE}
	    , 1, 0}
    ,
    {{EVENT}
	    , 1, 0}
    ,
    {{STANDALONESIG}
	    , 1, 0}
    ,
    {{MODULEREF}
	    , 1, 0}
    ,
    {{ASSEMBLY}
	    , 1, 0}
    ,
    {{ASSEMBLYREF}
	    , 1, 0}
    ,
    {{FILE}
	    , 1, 0}
    ,
    {{EXPORTEDTYPE}
	    , 1, 0}
    ,
    {{MANIFESTRESOURCE}
	    , 1, 0}
    ,
    {{TYPEDEF, TYPEREF, TYPESPEC}
	    , 3, 0}
    ,
    {{FIELDDEF, PARAMDEF, PROPERTY}
	    , 3, 0}
    ,
    {{METHODDEF, FIELDDEF, TYPEREF, TYPEDEF, PARAMDEF, INTERFACEIMPL,
			    MEMBERREF,
			    MODULE, PROPERTY, EVENT, STANDALONESIG, MODULEREF, TYPESPEC,	//PERMISSION??
		    ASSEMBLY, ASSEMBLYREF, FILE, EXPORTEDTYPE,
			    MANIFESTRESOURCE}
	    , 19, 0}
    ,
    {{FIELDDEF, PARAMDEF}
	    , 2, 0}
    ,
    {{TYPEDEF, METHODDEF, ASSEMBLY}
	    , 3, 0}
    ,
    {{TYPEDEF, TYPEREF, MODULEREF, METHODDEF, TYPESPEC}
	    , 5, 0}
    ,
    {{EVENT, PROPERTY}
	    , 2, 0}
    ,
    {{METHODDEF, MEMBERREF}
	    , 2, 0}
    ,
    {{FIELDDEF, METHODDEF}
	    , 2, 0}
    ,
    {{FILE, ASSEMBLYREF, EXPORTEDTYPE}
	    , 2, 0}
    ,
    {{UNUSED, UNUSED, METHODDEF, MEMBERREF, UNUSED}
	    , 5, 0}
    ,
    {{MODULE, MODULEREF, ASSEMBLYREF, TYPEREF}
	    , 4, 0}
};
