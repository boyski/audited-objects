/* 
 * Copyright (C) 2006 David Boyce.  All rights reserved.
 * Based on code purchased via RentACoder.com (Request Id 401892).
 *
 * This program is free software; you may redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
	Description:
		Patch the com runtime descriptor.
		Patch any metadata table that contains timestamped info
**/

#ifndef COM_H_37734534
#define COM_H_37734534

#include "common.h"

/* 64 bit QWORD structure */
typedef struct sQWORD {
    DWORD lo;
    DWORD hi;
} QWORD, *PQWORD;

/* header of metadata tables */
typedef struct t_MetaData_Table_Header {
    DWORD Reserved;		// Always 0
    BYTE MajorVersion;
    BYTE MinorVersion;
    BYTE HeapOffsetSizes;
    BYTE Reserved2;
    QWORD Valid;
    QWORD Sorted;
} METADATA_TABLE_HEADER, *PMETADATA_TABLE_HEADER;

#define	STRING_BITMASK		0x01
#define	GUID_BITMASK		0x02
#define	BLOB_BITMASK		0x04

/* stream information struct */
typedef struct t_Stream_Header {
    DWORD Offset;
    DWORD Size;
    BYTE Name[1];
} STREAM_HEADER, *PSTREAM_HEADER;

/* header of the metadata section */
typedef struct t_MetaData_Header {
    DWORD Signature;		// BSJB
    WORD MajorVersion;
    WORD MinorVersion;
    DWORD Unknown1;
    DWORD VersionSize;
    PBYTE VersionString;
    WORD Flags;
    WORD NumStreams;
    PBYTE Streams;
} METADATA_HEADER, *PMETADATA_HEADER;

/**
* Patch the com descriptor. Used by .NET executables
* RET: TRUE if sucess, else FALSE
*/
BOOL patch_com_descriptor();
/**
* Patch the metadata given the metadata header Used by .NET executables.
* com descriptor is in the .rdata section.
* This function is also called when we are patching an .NET OBJ file
*/
VOID patch_metadata(PMETADATA_HEADER p_metaDataHdr);

extern BYTE g_StringOffsetSize;
extern BYTE g_GUIDOffsetSize;
extern BYTE g_BlobOffsetSize;
extern PBYTE g_StringsPtr;

#endif
