#include <stdlib.h>
#include <stdio.h>

void goodbye(void)
{
    printf("Goodbye, World\n");
}
