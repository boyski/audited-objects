/* 
 * Copyright (C) 2006 David Boyce.  All rights reserved.
 * Based on code purchased via RentACoder.com (Request Id 401892).
 *
 * This program is free software; you may redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
		Patching all the TimeDateStamps in the resource section
		of an EXE or DLL file
**/

#include "resource.h"
#include "patch.h"

/**
* Patch resource directories recursivly
* IN: 'p_pResDir' directory to patch
* IN: 'p_resBase' base address of resources
* IN: 'p_level' the current directory depth we are at
*/
VOID
patch_res_dir(PIMAGE_RESOURCE_DIRECTORY p_pResDir, ULONG_PTR p_resBase,
	INT p_level)
{
    PIMAGE_RESOURCE_DIRECTORY_ENTRY pEntry;
    DWORD numEntries, i;
    static WORD rootID;

    /* Patch it! */
    /* Seems only to be filled with unique info in VB EXEs ? */
    LOGTABS(p_level);
    LOGPTR(p_pResDir->TimeDateStamp);
    p_pResDir->TimeDateStamp = 0;

    LOGTABS(p_level);
    LOGPTR(p_pResDir->MajorVersion);
    p_pResDir->MajorVersion = 0;

    LOGTABS(p_level);
    LOGPTR(p_pResDir->MinorVersion);
    p_pResDir->MinorVersion = 0;

    /* calculate total number of entries in this directory */
    numEntries = p_pResDir->NumberOfIdEntries +
	    p_pResDir->NumberOfNamedEntries;
    /* get pointer to first entry */
    pEntry = MAKE_PTR(PIMAGE_RESOURCE_DIRECTORY_ENTRY,
	    p_pResDir, sizeof(IMAGE_RESOURCE_DIRECTORY));
    /* iterate trough entries */
    for (i = 0; i < numEntries; i++, pEntry++) {
	LOGTABS(p_level);
	LOGPTR(pEntry->Id);
	if (p_level == 0)
	    rootID = pEntry->Id;
	/* if entry is a directroy then patch recurse */
	if (pEntry->DataIsDirectory != 0) {
	    PIMAGE_RESOURCE_DIRECTORY pDir =
		    MAKE_PTR(PIMAGE_RESOURCE_DIRECTORY, p_resBase,
		    pEntry->OffsetToDirectory);
	    patch_res_dir(pDir, p_resBase, p_level + 1);
	} else {
	    /* if its an data entry then check if we want to patch it */
	    if (rootID == (WORD) RT_VERSION) {
		PBYTE pResData = NULL;
		PIMAGE_RESOURCE_DATA_ENTRY pResEntry;
		pResEntry = MAKE_PTR(PIMAGE_RESOURCE_DATA_ENTRY, p_resBase,
			pEntry->OffsetToData);
		pResData = (PBYTE) rva_to_ptr(pResEntry->OffsetToData);

		LOGTABS(p_level);
		LOG("Erasing VERSION info resource");
		/* Patch it! */
		memset(pResData, 0x00, pResEntry->Size);
	    }
	}
    }
}

/**
* Patch the resource directory
* RET: TRUE if sucess, else FALSE
*/
BOOL
patch_resource()
{
    PIMAGE_DATA_DIRECTORY pDataDir = NULL;
    PIMAGE_RESOURCE_DIRECTORY pResDir = NULL;
    /* get data directory entry for resources */
    pDataDir = get_data_dir(IMAGE_DIRECTORY_ENTRY_RESOURCE);
    if (pDataDir == NULL || pDataDir->Size == 0)
	return FALSE;
    /* get first resource directory */
    pResDir =
	    (PIMAGE_RESOURCE_DIRECTORY) rva_to_ptr(pDataDir->
	    VirtualAddress);
    if (pResDir == NULL) {
	LOG("RVAtoPtr failed - patch_resource");
	return FALSE;
    }

    /* recurse the directory structure */
    patch_res_dir(pResDir, (ULONG_PTR) pResDir, 0);

    return TRUE;
}
