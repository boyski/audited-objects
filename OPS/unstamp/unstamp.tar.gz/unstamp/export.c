/* 
 * Copyright (C) 2006 David Boyce.  All rights reserved.
 * Based on code purchased via RentACoder.com (Request Id 401892).
 *
 * This program is free software; you may redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
	Description:
		Patching all the TimeDateStamps in the export table of
		an EXE or DLL file
**/

#include "export.h"
#include "patch.h"

/**
* Patch the export table
* RET: TRUE if sucess, else FALSE
*/
BOOL
patch_export()
{
    PIMAGE_DATA_DIRECTORY pDataDir = NULL;
    PIMAGE_EXPORT_DIRECTORY pExportDir = NULL;
    /* get pointer to data directory */
    pDataDir = get_data_dir(IMAGE_DIRECTORY_ENTRY_EXPORT);
    if (pDataDir == NULL || pDataDir->Size == 0)
	return FALSE;
    /* get pointer to export directory */
    pExportDir =
	    (PIMAGE_EXPORT_DIRECTORY) rva_to_ptr(pDataDir->VirtualAddress);
    if (pExportDir == NULL) {
	LOG("RVAtoPtr failed - patch_export\n");
	return FALSE;
    }
    /* Patch it! */
    LOGPTR(pExportDir->TimeDateStamp);
    pExportDir->TimeDateStamp = 0;

    return TRUE;
}
