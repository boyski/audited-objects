/* 
 * Copyright (C) 2006 David Boyce.  All rights reserved.
 * Based on code purchased via RentACoder.com (Request Id 401892).
 *
 * This program is free software; you may redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
	Description:  Patching all the TimeDateStamps in the bound
	import section of an EXE or DLL file

**/

#include "bound.h"
#include "patch.h"

/**
* Patch the bound import directory
* RET: TRUE if sucess, else FALSE
*/
BOOL
patch_bound()
{
    PIMAGE_DATA_DIRECTORY pDataDir = NULL;
    PIMAGE_BOUND_IMPORT_DESCRIPTOR pBImportDesc = NULL;
    PIMAGE_BOUND_FORWARDER_REF pForwRef = NULL;
    DWORD i, numForward;
    /* get data directory pointer */
    pDataDir = get_data_dir(IMAGE_DIRECTORY_ENTRY_BOUND_IMPORT);
    if (pDataDir == NULL || pDataDir->Size == 0)
	return FALSE;
    /* get first bound import descriptor. rva_to_ptr? */
    pBImportDesc = MAKE_PTR(PIMAGE_BOUND_IMPORT_DESCRIPTOR, g_baseAddr,
	    pDataDir->VirtualAddress);
    /* patch all import descriptors */
    while (pBImportDesc->TimeDateStamp) {
	pForwRef = MAKE_PTR(PIMAGE_BOUND_FORWARDER_REF, pBImportDesc,
		sizeof(IMAGE_BOUND_FORWARDER_REF));
	numForward = pBImportDesc->NumberOfModuleForwarderRefs;

	LOGPTR(pBImportDesc->TimeDateStamp);
	/* Patch it! */
	pBImportDesc->TimeDateStamp = 0;
	/* patch any forwarded imports too */
	for (i = 0; i < numForward; i++) {
	    /* Patch it! */
	    LOGPTR(pForwRef->TimeDateStamp);
	    pForwRef->TimeDateStamp = 0;

	    pForwRef++;
	    pBImportDesc =
		    MAKE_PTR(PIMAGE_BOUND_IMPORT_DESCRIPTOR, pBImportDesc,
		    sizeof(IMAGE_BOUND_FORWARDER_REF));
	}
	pBImportDesc++;
    }
    return TRUE;
}
