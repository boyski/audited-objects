/* 
 * Copyright (C) 2006 David Boyce.  All rights reserved.
 * Based on code purchased via RentACoder.com (Request Id 401892).
 *
 * This program is free software; you may redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
	Description:
		Patch the basic parts of a PE
	
**/
#ifndef PATCH_H_3788343346
#define PATCH_H_3788343346

#include "common.h"

extern ULONG_PTR g_baseAddr;
extern PIMAGE_DOS_HEADER g_pDosHeader;
extern PIMAGE_NT_HEADERS g_pNTHeader;
extern PIMAGE_SECTION_HEADER g_pFirstSection;
extern BOOL g_is64bit;

typedef struct t_flagToStr {
    DWORD m_flag;
    LPCSTR m_str;
} FLAGTOSTR, *PFLAGTOSTR;

/**
* Patch a memory mapped file
* IN: 'p_baseAddress' base address of mapping
*/
VOID patch_mapped_file(LPVOID p_baseAddress);
/**
* Find the section containing a certain RVA
* IN: 'p_RVA' relative virtual address
* RET: pointer to section, or NULL
*/
PIMAGE_SECTION_HEADER find_section(DWORD p_RVA);
/**
* Convert an RVA to a usuable pointer
* IN: 'p_RVA' relative virtual address
* RET: a pointer, or NULL
*/
LPVOID rva_to_ptr(DWORD p_RVA);
/**
* Get a pointer to a data directory of the PE
* IN: 'p_DataDir' the ID of the dir we want
* RET: pointer to data directory
*/
PIMAGE_DATA_DIRECTORY get_data_dir(DWORD p_DataDir);

#endif
