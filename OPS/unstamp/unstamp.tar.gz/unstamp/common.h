/* 
 * Copyright (C) 2006 David Boyce.  All rights reserved.
 * Based on code purchased via RentACoder.com (Request Id 401892).
 *
 * This program is free software; you may redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
	Description:
		Commonly used macros and functions
**/

#ifndef COMMON_H_367788734
#define COMMON_H_367788734

#include <windows.h>
#include <stdio.h>
#include <assert.h>

#define MAKE_PTR(type, a, b) (type)((ULONG_PTR)a + (ULONG_PTR)b)

/* #define DEBUG_OUTPUT */

#ifdef DEBUG_OUTPUT
#define LOG(str)		(printf("%s\n", str))
#define LOGPTR(ptr)		(printf("%s: 0x%08x\n", #ptr, ptr))
#define LOGUINT(uint)	(printf("%s: %u\n", #uint, uint))
#define LOGSTR(str)		(printf("%s: %s\n", #str, str))
#define LOGSTRSTR(a,b)	(printf("%s: %s\n", a, b))
#define LOGSTRPTR(a,b)	(printf("%s: 0x%08x\n", a, b))
#define LOGTAB()		(printf("\t"))
#else
#define LOG(str)
#define LOGPTR(ptr)
#define LOGUINT(uint)
#define LOGSTR(str)
#define LOGSTRSTR(a,b)
#define LOGSTRPTR(a,b)
#define LOGTAB()
#endif

__inline VOID
LOGTABS(INT n)
{
    INT i;
    for (i = 0; i < n; i++)
	LOGTAB();
}

#endif
