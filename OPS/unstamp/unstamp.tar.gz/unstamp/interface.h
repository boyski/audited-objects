/* 
 * Copyright (C) 2006 David Boyce.  All rights reserved.
 * Based on code purchased via RentACoder.com (Request Id 401892).
 *
 * This program is free software; you may redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
	Description:
		Patch timestamps in an EXE/DLL file.
**/
#ifndef INTERFACE_H_3788343346
#define INTERFACE_H_3788343346

#include "common.h"

/* callback typedef */
typedef VOID(__stdcall * t_callback) (PBYTE p_pBytes, DWORD p_size);

/**
* Patch any timestamps or similar in an EXE/DLL. 
* If input file is not an PE file, then its just sent back
* unmodified to the callback function.
* IN: 'p_fileName' name/path of file to patch
* IN: 'p_pfCallback' callback function that recieves a buffer of bytes
* representing the patched file.
*/
BOOL patchEXE(LPCSTR p_fileName, t_callback p_pfCallback);

#endif
