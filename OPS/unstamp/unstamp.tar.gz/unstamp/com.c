/* 
 * Copyright (C) 2006 David Boyce.  All rights reserved.
 * Based on code purchased via RentACoder.com (Request Id 401892).
 *
 * This program is free software; you may redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
	Description:
		Patch the com runtime descriptor.
		Patch any metadata table that contains timestamped info
**/

#include "com.h"
#include "com_read.h"
#include "com_types.h"
#include "patch.h"

PBYTE g_StringsPtr = NULL;
PBYTE g_BlobPtr = NULL;
PBYTE g_GUIDPtr = NULL;
PBYTE g_USPtr = NULL;
PBYTE g_TablesPtr = NULL;

PSTREAM_HEADER g_TablesHdr = NULL;
PSTREAM_HEADER g_StringsHdr = NULL;
PSTREAM_HEADER g_BlobHdr = NULL;
PSTREAM_HEADER g_GUIDHdr = NULL;
PSTREAM_HEADER g_USHdr = NULL;

BYTE g_StringOffsetSize;
BYTE g_GUIDOffsetSize;
BYTE g_BlobOffsetSize;

/**
* calculate bits needed to represent the number of rows in a table
* IN: 'p_dword' number of rows
* RET: bits needed
*/
INT
row_bits_needed(DWORD p_dword)
{
    INT i, b = 32;
    for (i = 31; i >= 0; i--, b--) {
	if (p_dword & (1 << i))
	    break;
    }
    return b;
}

/**
* calculate bits needed for encoding. if there are 5 different
* possible indices in a type then we need 3 bits
* IN: 'p_numIndex' number of indices
* RET: bits needed
*/
INT
enc_bits_needed(BYTE p_numIndex)
{
    INT i;
    for (i = 7; i >= 0; i--) {
	if ((p_numIndex - 1) & (1 << i))
	    return i + 1;
    }
    return 0;
}

/**
* Calculate the size of a certain index type 
* IN/OUT: 'p_pType' pointer type to calculate size of
*/
VOID
calc_index_size(PTYPEINDEX p_pType)
{
    INT i, num = 0;
    for (i = 0; i < p_pType->NumIDs; i++) {
	INT n = row_bits_needed(g_tableInfo[p_pType->TypeIDs[i]].NumRows);
	if (n > num)
	    num = n;
    }
    num += enc_bits_needed(p_pType->NumIDs);
    p_pType->BytesNeeded = (num > 16) ? 4 : 2;
}

/**
* Precalculate all our index type sizes when we know
* the number of rows in each table.
*/
VOID
precalc_type_sizes()
{
    INT i;
    for (i = 0; i < NUM_INDEX_TYPES; i++)
	calc_index_size(&g_types[i]);
}

/**
* calculate  number of tables
* IN: 'p_Valid' 64 bits, 1 for existing table, 0 for non existing
* RET: number of tables
*/
BYTE
calc_num_tables(QWORD p_Valid)
{
    INT i, c = 0;
    for (i = 0; i < 32; i++) {
	if ((p_Valid.hi & (1 << i)))
	    c++;
	if ((p_Valid.lo & (1 << i)))
	    c++;
    }
    return c;
}

/**
* check if a table with a certain id exists in an exe
* IN: 'p_Valid' 64 bits, 1 for existing table, 0 for non existing
* IN: 'i' id of table to check
* RET: TRUE if exists, else FALSE
*/
BOOL
is_valid_table(QWORD p_Valid, INT i)
{
    return (i < 32) ? ((p_Valid.lo & (1 << i)) !=
	    0) : ((p_Valid.hi & (1 << (i - 32))) != 0);
}

/**
* Read all the tables. phew. patch the ones that needs patching.
* IN: 'p_TablesPtr' pointer to start of tables
*/
BOOL
read_tables(PBYTE p_TablesPtr)
{
    PMETADATA_TABLE_HEADER pTableHead;
    PDWORD pRowSizePtr;
    PBYTE pTables;
    DWORD i;
    /* get pointer to metadata table header */
    pTableHead = (PMETADATA_TABLE_HEADER) p_TablesPtr;
    /* get number of bytes that the heap offsets are */
    g_StringOffsetSize =
	    (pTableHead->HeapOffsetSizes & STRING_BITMASK) ? 4 : 2;
    g_GUIDOffsetSize =
	    (pTableHead->HeapOffsetSizes & GUID_BITMASK) ? 4 : 2;
    g_BlobOffsetSize =
	    (pTableHead->HeapOffsetSizes & BLOB_BITMASK) ? 4 : 2;
    /* get pointer to array of section sizes */
    pRowSizePtr =
	    MAKE_PTR(PDWORD, pTableHead, sizeof(METADATA_TABLE_HEADER));
    for (i = 0; i < 64; i++) {
	if (is_valid_table(pTableHead->Valid, i))
	    g_tableInfo[i].NumRows = *pRowSizePtr++;
    }
    /* calculate the sizes of the metadata table entry types */
    precalc_type_sizes();
    /* get pointer to the tables */
    pTables = (PBYTE) pRowSizePtr;
    /* Read the tables. */
    for (i = 0; i < 64; i++) {
	/* check if this table exists in file */
	if (is_valid_table(pTableHead->Valid, i)) {
	    DWORD row;
	    LOGSTRSTR("TABLE START:", g_tableInfo[i].Name);
	    LOGSTRPTR("TABLE OFFSET:",
		    ((ULONG_PTR) pTableHead - g_baseAddr));

	    if (strcmp(g_tableInfo[i].Name, "Module") == 0) {
		read_Module_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "TypeRef") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_TypeRef_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "TypeDef") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_TypeDef_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "Field") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_Field_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "MethodDef") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_MethodDef_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "Param") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_Param_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "InterfaceImpl") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_InterfaceImpl_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "MemberRef") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_MemberRef_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "Constant") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_Constant_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "CustomAttribute") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_CustomAttribute_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "FieldMarshal") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_FieldMarshal_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "DeclSecurity") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_DeclSecurity_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "ClassLayout") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_ClassLayout_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "FieldLayout") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_FieldLayout_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "StandAloneSig") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_StandAloneSig_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "EventMap") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_EventMap_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "Event") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_Event_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "PropertyMap") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_PropertyMap_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "Property") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_Property_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "MethodSemantics") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_MethodSemantics_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "MethodImpl") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_MethodImpl_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "ModuleRef") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_ModuleRef_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "TypeSpec") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_TypeSpec_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "ImplMap") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_ImplMap_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "FieldRVA") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_FieldRVA_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "Assembly") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_Assembly_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name,
			    "AssemblyProcessor") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_AssemblyProcessor_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "AssemblyOS") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_AssemblyOS_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "AssemblyRef") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_AssemblyRef_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "File") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_File_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "ExportedType") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_ExportedType_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name,
			    "ManifestResource") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_ManifestResource_TableRow(&pTables);
	    } else if (strcmp(g_tableInfo[i].Name, "NestedClass") == 0) {
		for (row = 0; row < g_tableInfo[i].NumRows; row++)
		    read_NestedClass_TableRow(&pTables);
	    }
	}
    }
    return TRUE;
}

/**
* read stream headers and save pointers in global variables
* IN: 'p_metaHdr' metadata header
* IN: 'p_metaHdrStart' pointer to start of meta header.
*		cant use the one of 'p_metaHdr' since its a copy of the mapped one.
*/
BOOL
get_stream_pointers(PMETADATA_HEADER p_metaHdr, PBYTE p_metaHdrStart)
{
    INT i;
    PBYTE streamPtr = p_metaHdr->Streams;

    for (i = 0; i < p_metaHdr->NumStreams; i++) {
	PSTREAM_HEADER head;
	head = read_stream_header(&streamPtr);

	LOGSTRSTR("HEAP NAME: ", &head->Name[0]);
	LOGSTRPTR("HEAP START:",
		((ULONG_PTR) p_metaHdrStart + head->Offset - g_baseAddr));
	LOGSTRPTR("HEAP END:",
		((ULONG_PTR) p_metaHdrStart + head->Offset - g_baseAddr +
			head->Size));
	/* Seems like the table is called #- in OBJ files and #~ in EXEs */
	if (strcmp(&head->Name[0], "#~") == 0
		|| strcmp(&head->Name[0], "#-") == 0) {
	    g_TablesHdr = head;
	    g_TablesPtr = MAKE_PTR(PBYTE, p_metaHdrStart, head->Offset);
	} else if (strcmp(&head->Name[0], "#Strings") == 0) {
	    g_StringsHdr = head;
	    g_StringsPtr = MAKE_PTR(PBYTE, p_metaHdrStart, head->Offset);
	} else if (strcmp(&head->Name[0], "#US") == 0) {
	    g_USHdr = head;
	    g_USPtr = MAKE_PTR(PBYTE, p_metaHdrStart, head->Offset);
	} else if (strcmp(&head->Name[0], "#GUID") == 0) {
	    g_GUIDHdr = head;
	    g_GUIDPtr = MAKE_PTR(PBYTE, p_metaHdrStart, head->Offset);
	} else if (strcmp(&head->Name[0], "#Blob") == 0) {
	    g_BlobHdr = head;
	    g_BlobPtr = MAKE_PTR(PBYTE, p_metaHdrStart, head->Offset);
	}
    }

    return TRUE;
}

/**
* read the metadata header
* OUT: 'p_metaHead' pointer to header to fill
* IN: 'p_startHead' pointer to start of metadata header
*/
VOID
read_meta_data_header(PMETADATA_HEADER p_metaHead, PBYTE p_startHead)
{
    p_metaHead->Signature = read_dword(&p_startHead);
    p_metaHead->MajorVersion = read_word(&p_startHead);
    p_metaHead->MinorVersion = read_word(&p_startHead);
    p_metaHead->Unknown1 = read_dword(&p_startHead);
    p_metaHead->VersionSize = read_dword(&p_startHead);
    p_metaHead->VersionString = p_startHead;

    seek_bytes(&p_startHead, p_metaHead->VersionSize);

    p_metaHead->Flags = read_word(&p_startHead);
    p_metaHead->NumStreams = read_word(&p_startHead);
    p_metaHead->Streams = p_startHead;
}

/**
* Dump some info about the com header
*/
VOID
dump_com_header(PIMAGE_COR20_HEADER p_pComHdr)
{
    LOGPTR((ULONG_PTR) rva_to_ptr(p_pComHdr->MetaData.VirtualAddress) -
	    g_baseAddr);
    LOGPTR(p_pComHdr->MetaData.Size);
    LOGPTR((ULONG_PTR) rva_to_ptr(p_pComHdr->Resources.VirtualAddress) -
	    g_baseAddr);
    LOGPTR(p_pComHdr->Resources.Size);
    LOGPTR((ULONG_PTR) rva_to_ptr(p_pComHdr->StrongNameSignature.
		    VirtualAddress) - g_baseAddr);
    LOGPTR(p_pComHdr->StrongNameSignature.Size);
    LOGPTR((ULONG_PTR) rva_to_ptr(p_pComHdr->CodeManagerTable.
		    VirtualAddress) - g_baseAddr);
    LOGPTR(p_pComHdr->CodeManagerTable.Size);
    LOGPTR((ULONG_PTR) rva_to_ptr(p_pComHdr->VTableFixups.VirtualAddress) -
	    g_baseAddr);
    LOGPTR(p_pComHdr->VTableFixups.Size);
    LOGPTR((ULONG_PTR) rva_to_ptr(p_pComHdr->ManagedNativeHeader.
		    VirtualAddress) - g_baseAddr);
    LOGPTR(p_pComHdr->ManagedNativeHeader.Size);
}

/**
* Patch the com descriptor. Used by .NET executables.
* com descriptor is in the .rdata section
* RET: TRUE if sucess, else FALSE
*/
BOOL
patch_com_descriptor()
{
    PIMAGE_DATA_DIRECTORY pDataDir = NULL;
    PIMAGE_COR20_HEADER pComHead = NULL;
    PMETADATA_HEADER pMetaHeadPtr = NULL;

    PCHAR dataPtr = NULL;
    PDWORD dwPtr = NULL;
    /* get data directory pointer */
    pDataDir = get_data_dir(IMAGE_DIRECTORY_ENTRY_COM_DESCRIPTOR);
    if (pDataDir == NULL || pDataDir->Size == 0)
	return FALSE;
    /* get pointer to com runtime header */
    pComHead = (PIMAGE_COR20_HEADER) rva_to_ptr(pDataDir->VirtualAddress);
    if (pComHead == NULL) {
	LOG("rva_to_ptr failed - patch_com_descriptor\n");
	return FALSE;
    }
    /* dump info about the com header */
    dump_com_header(pComHead);
    /* get pointer to metadata header */
    pMetaHeadPtr =
	    (PMETADATA_HEADER) rva_to_ptr(pComHead->MetaData.
	    VirtualAddress);
    /* patch the metadata */
    patch_metadata(pMetaHeadPtr);

    return TRUE;
}

/**
* Patch the metadata given the metadata header Used by .NET executables.
* com descriptor is in the .rdata section.
* This function is also called when we are patching an .NET OBJ file
*/
VOID
patch_metadata(PMETADATA_HEADER p_metaDataHdr)
{
    METADATA_HEADER MetaHdr;
    /* read metadata header */
    read_meta_data_header(&MetaHdr, (PBYTE) p_metaDataHdr);
    /* read the stream headers and save their pointers */
    get_stream_pointers(&MetaHdr, (PBYTE) p_metaDataHdr);
    /* read all the tables */
    read_tables(g_TablesPtr);
    /* Patch GUIDs! */
    memset(g_GUIDPtr, 0x00, g_GUIDHdr->Size);
}
