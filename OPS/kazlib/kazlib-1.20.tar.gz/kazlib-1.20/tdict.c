// gcc -g -W -Wall -I. -o tdict tdict.c -L/vobs_ao/client/OPS/$PLATFORM/lib -lkaz-dbg

#include "dict.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

typedef struct {
    const char *key;
    int other_data;
} testnode_t;

int
tcmp(const void *p1, const void *p2)
{
    return strcmp(p1, p2);
}

int
main(int argc, char *argv[])
{
    dict_t *dict1;
    dnode_t *dnp;
    testnode_t *tnp;
    int i;

    dict1 = dict_create(argc, (dict_comp_t) tcmp);

    for (i = 1; i < argc; i++) {
	if (! dict_lookup(dict1, argv[i])) {
	    tnp = calloc(1, sizeof(testnode_t));
	    tnp->key = strdup(argv[i]);
	    tnp->other_data = i;
	    dnp = dnode_create(tnp);
	    dict_insert(dict1, dnp, tnp->key);
	}
    }

    for (dnp = dict_first(dict1); dnp; dnp = dict_next(dict1, dnp)) {
	tnp = (testnode_t *)dnode_get(dnp);
	printf("%s\n", tnp->key);
    }

    return 0;
}
